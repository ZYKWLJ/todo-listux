# ifndef MODIFY_H
# define MODIFY_H
#include "../include.h"
int modify(TaskYear *year_task, int year, int month, int day, int index, int argc, char **argv);
#endif