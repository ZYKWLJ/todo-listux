# ifndef DELETE_H
# define DELETE_H
#include "../include.h"
int delete_(TaskYear *year_task, int year, int month, int day, int index, int argc, char **argv);
#endif