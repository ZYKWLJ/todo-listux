# ifndef FIND_H
# define FIND_H
#include "../include.h"
int find(int year,int month,int day,char*content,Task ***task_year );
#endif