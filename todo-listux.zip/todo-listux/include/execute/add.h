# ifndef ADD_H
# define ADD_H
#include "../include.h"
int add(TaskYear *year_task, int year, int month, int day, int index, int argc, char **argv);
#endif