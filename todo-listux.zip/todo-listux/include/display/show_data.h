#ifndef SHOW_DATA_H
#define SHOW_DATA_H
#include "../include.h"
void display_current_date_tasks(TaskYear* task_year,int year, int month, int day );
#endif