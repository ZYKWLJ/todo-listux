# ifndef _COLOR_H_
# define _COLOR_H_
#define GREEN "\033[32m"//绿色专用于请输入指令提示信息
#define RED "\033[31m"//红色专用于错误提示信息
#define BLUE "\033[34m"//蓝色专用于章节名
#define PURPLE "\033[35m"//紫色专用于指引信息
#define YELLOW "\033[33m"//黄色专用于各个指令执行前缀！
#define RESET "\033[0m"
#define BOLD "\033[1m"//加粗
#endif