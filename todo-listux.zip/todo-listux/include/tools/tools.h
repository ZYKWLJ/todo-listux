#ifndef TOOLS_H
#define TOOLS_H
int is_leap_year(int year);
void get_current_date(int *year, int *month, int *day);
int day_of_year(int year, int month, int day) ;

#endif