#ifndef MONTH_H
#define MONTH_H
extern int MONTHS[12];
#endif