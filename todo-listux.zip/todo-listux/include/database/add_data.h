#ifndef ADD_DATA_H
#define ADD_DATA_H
#include "../include.h"
void add_task(TaskYear *year_tasks, int year, int month, int day, int index, char *content);//添加为那年那月那日的第几个任务
#endif