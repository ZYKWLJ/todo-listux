#ifndef SAVE_DATA_H
#define SAVE_DATA_H
#include "../include.h"

// 保存任务数据到文件
void save_data(TaskYear *year_tasks, int year);
#endif