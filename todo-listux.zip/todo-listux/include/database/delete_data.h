#ifndef DELETE_DATA_H
#define DELETE_DATA_H
#include "../include.h"
void delete_task(TaskYear *year_tasks, int year, int month, int day, int index);
#endif